package org.aicl.raytracerchallenge.primitives.shape;

import org.aicl.raytracerchallenge.primitives.Point;
import org.aicl.raytracerchallenge.primitives.Vector;
import org.aicl.raytracerchallenge.primitives.ray.Ray;
import org.aicl.raytracerchallenge.primitives.ray.RayIntersection;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class CubeTest {
    @Test
    public void testRayIntersectCube(){
        Cube cube = new Cube();
        ArrayList<Point>  origins = new ArrayList<>();
        ArrayList<Vector> directions = new ArrayList<>();
        ArrayList<Double> t1s = new ArrayList<>();
        ArrayList<Double> t2s = new ArrayList<>();

        origins.add(new Point(5, 0.5, 0)); directions.add(new Vector(-1, 0, 0)); t1s.add(4.); t2s.add(6.); // +x
        origins.add(new Point(-5, 0.5, 0)); directions.add(new Vector(1, 0, 0)); t1s.add(4.); t2s.add(6.); // -x
        origins.add(new Point(0.5, 5, 0)); directions.add(new Vector(0, -1, 0)); t1s.add(4.); t2s.add(6.); // +y
        origins.add(new Point(0.5, -5, 0)); directions.add(new Vector(0, 1, 0)); t1s.add(4.); t2s.add(6.); // -y
        origins.add(new Point(0.5, 0, 5)); directions.add(new Vector(0, 0, -1)); t1s.add(4.); t2s.add(6.); // +z
        origins.add(new Point(0.5, 0, -5)); directions.add(new Vector(0, 0, 1)); t1s.add(4.); t2s.add(6.); // -z
        origins.add(new Point(0., 0.5, 0)); directions.add(new Vector(0, 0, 1)); t1s.add(-1.); t2s.add(1.); // inside


        for(int i = 0; i < origins.size(); i++){
            Ray ray = new Ray(origins.get(i), directions.get(i));
            RayIntersection intersections = cube.localIntersect(ray);
            assertEquals(2, intersections.count);
            assertEquals(t1s.get(i), intersections.getIntersection(0).time, 0.00001);
            assertEquals(t2s.get(i), intersections.getIntersection(1).time, 0.00001);
        }
    }
}
