package org.aicl.raytracerchallenge.puttogether.chapter3;

import org.junit.jupiter.api.Test;

public class Chapter3PutTogether {
    @Test
    public void letsPutTogether(){
        PutTogetherChap3 p = new PutTogetherChap3();
    }
}
