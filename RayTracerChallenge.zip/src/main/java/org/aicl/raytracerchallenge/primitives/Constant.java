package org.aicl.raytracerchallenge.primitives;

public class Constant {
    public static float epsilon = 0.00001f;
}
