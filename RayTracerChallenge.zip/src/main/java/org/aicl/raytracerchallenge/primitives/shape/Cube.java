package org.aicl.raytracerchallenge.primitives.shape;

import org.aicl.raytracerchallenge.primitives.Tuple;
import org.aicl.raytracerchallenge.primitives.ray.Ray;
import org.aicl.raytracerchallenge.primitives.ray.RayIntersection;

import java.util.UUID;

public class Cube extends Shape {
    private String id;

    public Cube() {
        super();
        id = UUID.randomUUID().toString();
    }

    @Override
    public RayIntersection localIntersect(Ray transformedRay) {
        return null;
    }

    @Override
    public Tuple localNormal(Tuple objectPoint) {
        return null;
    }

    @Override
    public boolean isSame(Shape input) {
        return (input instanceof Cube) && id.equals(input.getId());
    }

    @Override
    public boolean isSameCharacteristics(Shape shape) {
        return isSame(shape);
    }

    @Override
    public String getId() {
        return id;
    }
}
